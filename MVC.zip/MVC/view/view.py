import sys
sys.path.append('..')

from controller import controller

def createAccount():
    name=input("Enter your name :")
    email = input("Enter your email")
    user = controller.createAcc(name, email)
    print(f"Helllo {user.name} , you account has been successfully created..")
    print(f"A/c No : {user.getAccNo()}")
    print(f"Pin : {user.getPin()}")
    print(f"Your balance = {user.getBlc()}")

def balanceEnquiry():
    email = input("Enter your email :")
    pin = input("Enter your pin : ")
    res = controller.balEnquiry(email,pin)
    if isinstance(res,str):
        print(res)
    else:
        print(f"Hello {res.name} , your balance is {res.bal}")
        
def withdraw():
    pass

def menu():
    print("""
    Press 1. to Create Account
     Press 2. for Withdraw
     Press 3. for Balance check
     Press 4. for Balance Transfer
     Press 5. to deposit amount""")

    choice = input("Enter your choice : ")

    operations = {"1":createAccount,"2":withdraw,"3":balanceEnquiry,
                  # "4":balanceTransfer,
                  # "5":depositAmount

                  }
    operations.get(choice)()

menu()




























