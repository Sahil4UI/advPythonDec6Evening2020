import mysql.connector

con= mysql.connector.connect(
    host="localhost",
    user="root",
    password="root1234",
    database="Kotak_bank"
)

cursor = con.cursor()
#q="CREATE TABLE BANK_ACC (AC_NO INT,NAME VARCHAR(20),EMAIL VARCHAR(20),PIN CHAR(4),BLC INT)"
# cursor.execute(q)

def insert(ac_no,name,email,pin,blc):
    query = "INSERT INTO BANK_ACC VALUES(%s,%s,%s,%s,%s)"
    values = (ac_no,name,email,pin,blc)
    cursor.execute(query,values)
    con.commit()

def select():
    pass