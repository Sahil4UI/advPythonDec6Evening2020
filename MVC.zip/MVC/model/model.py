import random
import database
class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.acc_no = random.randint(100,10000000)
        self.pin = "1234"
        self.balance = 0

    def getAccNo(self):
        return self.acc_no

    def getPin(self):
        return self.pin

    def getBlc(self):
        return self.balance

def createAccount(name,email):
    obj = Bank(name,email)
    database.insert(obj.acc_no,obj.name,obj.email,obj.pin,obj.balance)


def enquiry(email,pin):
    pass
    # for i in range(len(users)):
    #     if users[i].email == email and users[i].getPin() == pin:
    #         return users[i]
    #     else:
    #         return "Invalid Details..."