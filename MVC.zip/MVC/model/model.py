import random
import mysql.connector

con= mysql.connector.connect(
    host="localhost",
    user="root",
    password="root1234",
    database="Kotak_bank"
)


cursor = con.cursor()
# q="CREATE TABLE BANK_ACC (AC_NO INT,NAME VARCHAR(20),EMAIL VARCHAR(20),PIN CHAR(4),BLC INT)"
# cursor.execute(q)


class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.acc_no = random.randint(100,10000000)
        self.pin = "1234"
        self.balance = 0

    def getAccNo(self):
        return self.acc_no

    def getPin(self):
        return self.pin

    def getBlc(self):
        return self.balance

def createAccount(name,email):
    obj = Bank(name,email)
    query = "INSERT INTO BANK_ACC VALUES(%s,%s,%s,%s,%s)"
    value = (obj.acc_no, obj.name, obj.email, obj.pin, obj.balance)
    cursor.execute(query, value)
    con.commit()
    return obj



def enquiry(email,pin):
    query = "select NAME,BLC from BANK_ACC where EMAIL=%s and PIN=%s"
    value = (email,pin)
    cursor.execute(query,value)
    result = cursor.fetchone()
    return result
    # for i in range(len(users)):
    #     if users[i].email == email and users[i].getPin() == pin:
    #         return users[i]
    #     else:
    #         return "Invalid Details..."
