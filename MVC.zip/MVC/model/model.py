import random
class Bank:
    def __init__(self,name,email):
        self.name = name
        self.email = email
        self.acc_no = random.randint(100,10000000)
        self.pin = 1234
        self.balance = 0


    def getAccNo(self):
        return self.acc_no

    def getPin(self):
        return self.pin

    def getBlc(self):
        return self.balance
users = []

def createAccount(name,email):
    obj = Bank(name,email)
    users.append(obj)
    return obj
